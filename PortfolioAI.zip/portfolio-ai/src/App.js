import React, { useState } from 'react';
import PortfolioForm from './components/PortfolioForm';
import PortfolioCard from './components/PortfolioCard';

function App() {
  const [projects, setProjects] = useState([]);
  const [darkMode, setDarkMode] = useState(false);

  const addProject = (project) => setProjects([...projects, project]);

  return (
    <div className={darkMode ? "dark" : ""}>
      <div className="min-h-screen p-6 transition-colors duration-500">
        <header className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Aylin Erkut Portfolio</h1>
          <button
            className="px-4 py-2 rounded bg-gray-800 text-white dark:bg-gray-200 dark:text-black"
            onClick={() => setDarkMode(!darkMode)}
          >
            {darkMode ? 'Light Mode' : 'Dark Mode'}
          </button>
        </header>

        <PortfolioForm addProject={addProject} />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {projects.map((proj, idx) => (
            <PortfolioCard key={idx} project={proj} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;