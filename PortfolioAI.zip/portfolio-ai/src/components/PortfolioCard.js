import React from 'react';

function PortfolioCard({ project }) {
  return (
    <div className="p-6 border rounded-lg shadow-lg hover:scale-105 transform transition-transform bg-white dark:bg-gray-800">
      <h2 className="text-xl font-semibold mb-2">{project.title}</h2>
      <p>{project.description}</p>
    </div>
  );
}

export default PortfolioCard;