import React, { useState } from 'react';

const aiGenerateDescription = (input) => {
  return `Profesyonel bir şekilde hazırlanan proje: "${input}" ile dikkat çekici bir yetenek gösterimi sağlanıyor.`;
};

function PortfolioForm({ addProject }) {
  const [title, setTitle] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title) return;
    const description = aiGenerateDescription(title);
    addProject({ title, description });
    setTitle('');
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
      <input
        type="text"
        placeholder="Proje veya yetenek girin..."
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="flex-1 px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:text-white"
      />
      <button
        type="submit"
        className="px-6 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
      >
        Ekle
      </button>
    </form>
  );
}

export default PortfolioForm;